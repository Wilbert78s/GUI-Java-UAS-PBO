/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dell
 */
import java.util.*;
class data{
    protected String rute;
    protected String nama;
    private String jam;
    public data(String nama,String rute){
        this.nama=nama;
        this.rute=rute;
    }

    public String getNama(){
        return this.nama;
    }

    public void setRute(String rute) {
        this.rute = rute;
    }

    public String getRute(){
        return this.rute;
    }
    public String getJam() {
        return jam;
    }

    public void setJam(String jam) {
        this.jam = jam;
    }
}

class PesawatKomersial extends data{
    private int tiket;
    private String kelas;
    public PesawatKomersial(String nama,String kelas,String rute,int tiket){
        super(nama,rute);
        this.kelas=kelas;
        this.tiket=tiket;
    }

    public String getKelas(){
        return this.kelas;
    }
    public int getTiket(){
        return this.tiket;
    }
}

class JetPribadi extends data{
    private int harga;
    private int penumpang;
    public JetPribadi(String nama,int penumpang,int harga,String rute){
        super(nama,rute);
        this.harga=harga;
        this.penumpang=penumpang;
    }

    public String getNama() {
        return nama;
    }

    public int getHarga(){
        return this.harga;
    }

    public int getPenumpang(){
        return this.penumpang;
    }

}

class Pembeli{
    private String namaPembeli;
    private int umur;

    public String getNamaPembeli() {
        return namaPembeli;
    }

    public void setNamaPembeli(String namaPembeli) {
        this.namaPembeli = namaPembeli;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }
    
}
